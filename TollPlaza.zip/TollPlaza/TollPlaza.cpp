#include<iostream>
#include<time.h>
#include<string>
#include<fstream>
#include<cmath>
#include <stdlib.h>
#include<ios>
#include<limits>
using namespace std;

const float  f_tag_bal[7] = {300.0,440.0,800.0,700.0,800.0,800.0,800.0};
const float	 monthly_bal[7]={768.00,1344.00,2687.00,4319.00,4319.00,4319.00,4319.00};
const float	 toll_S_price[7]={26.00,45.00,90.00,144.00,144.00,192.00,144.0};
const float	 toll_R_price[7]={38.00,67.00,134.00,216.00,216.00,216.00,216.00};
int no_of_vehicle=0; //-------------------------->//to store number of vehicles passed.


class TollPlaza{
	private:
		string by_vech_ty; //--------------------------->//to perform searching by vehicle type. 
	    string by_vech_no;  //------------------------->//to perform searching by vehicle number.
		string mon;   //------------------------------->//to store extracted month
		string yer;   //------------------------------->//to store extracted year
		int opert_code; //----------------------------> // to store unique operator code.
		int lane;       //----------------------------> //to store lane number
		char way;      //------------------------------>// to store type of journey(single or return)
		char monthly_pass; //-------------------------->//to store monthly_pass info.(Yes/No) 
		char fast_tag;//------------------------------->//to store fast_tag info.(Yes/No)
		int  vech_ty;//-------------------------------->//to store type of vehicle from the list formed in numeric form
		string vehical_no; //-------------------------->//to store vehicle number.
  		//string dummy; 
		string oper_t;     //-------------------------->//to store operator name.
		float balance;    //--------------------------->//to store monthly_remaining_balance.
		float f_bal;      //--------------------------->//to store fast_tag_remaining_balance.
		/*float f_tag_bal[7]; //------------------------->//to store fast_tag_balance.    
		float monthly_bal[7]; //----------------------->//to store monthly_pass_balance for various types.
		float toll_S_price[7]; //---------------------->//to store single journey balance.
		float toll_R_price[7]; //---------------------->//to store return journey balance..*/
		int pass_no;   //------------------------------>//to store pass number of monthly pass.
		string date2;  //------------------------------->//to copy date in this variable.
		float amt;   //---------------------------------->//to know amount is paid or not(incase not having monthly pass and fast tag). )
struct date_time{                     
			string date;                  //to store date from user
			string time;                  //to store time from user
		}d_ate,t_ime;
	public:
		
		 TollPlaza(){
		
		amt = 0.0;
       	balance = 0.0;
    	f_bal = 0.0;
		  }
		 
	     void input();
	     float Amount_Cal();
	     void creating_file();
	     void search(int x);
	     void display();
	      ~TollPlaza(){ }
	    void distruct(){
	    	TollPlaza(); this->TollPlaza::~TollPlaza();
	    }
	    
	    
};


void TollPlaza::input(){
  oper_t = "";
  if(d_ate.date!=date2){
  no_of_vehicle = 0;
  }
  //cout<<"Please press enter (only first time) to continue...\n\n\n";
  cin.ignore(numeric_limits<streamsize>::max(),'\n');  // to discard the input buffer
	cout<<"Enter name of Operator: ";
	  getline(cin,oper_t);
	cout<<"Enter the operator code: ";
	  cin>>opert_code;
	cout<<"Enter the lane number the operator is operating(1 to 6): ";
	  cin>>lane;
	cout<<"Date(dd-mm-yy) : ";
      cin>>d_ate.date;
      
	cout<<"Time(hrs:min) : ";
	  cin>>t_ime.time;
	cout<<"Enter vehical number : ";
	  cin>>vehical_no;
    cout<<"****Various Categories of vehicles****"<<endl<<endl;
    
	cout.width(18);
	cout.setf(ios::left, ios::adjustfield);
	cout<<" Car/Jeep/Van : ";
	cout.width(35);
	cout.setf(ios::right, ios::adjustfield);
	cout<<"1"<<endl;
    cout.width(18);
	cout<<" Light Comercial Vehicle : ";
	cout.width(26);
	cout.setf(ios::right, ios::adjustfield);
	cout<<"2"<<endl;
	cout.width(18);
	cout.setf(ios::left, ios::adjustfield);
	cout<<" Bus/Truck : ";
	cout.width(35);
	cout.setf(ios::right, ios::adjustfield);
	cout<<"3"<<endl;
	cout.width(18);
	cout.setf(ios::left, ios::adjustfield);
	cout<<" Upto 3 Axle Vehicle : ";
	cout.width(30);
	cout.setf(ios::right, ios::adjustfield);
	cout<<"4"<<endl;
	cout.width(18);
	cout.setf(ios::left, ios::adjustfield);
	cout<<" 4 to 6 Axle : ";
	cout.width(35);
	cout.setf(ios::right, ios::adjustfield);
	cout<<"5"<<endl;
	cout.width(18);
	cout.setf(ios::left, ios::adjustfield);
	cout<<" HCM/EMC : ";      //Heavy Construction Machinary / Earth Moving Equipment
	cout.width(35);
	cout.setf(ios::right, ios::adjustfield);
	cout<<"6"<<endl;
	cout.width(28);
	cout.setf(ios::left, ios::adjustfield);
	cout<<" 7 or more Axle : ";
	cout.width(25);
	cout.setf(ios::right, ios::adjustfield);
	cout<<"7"<<endl;
	cout.width(18);
	cout.setf(ios::left, ios::adjustfield);
	cout<<" Exempt type-Ambulance/Police/Poltician : ";
	cout.width(11);
	cout.setf(ios::right, ios::adjustfield);
	cout<<"8"<<endl;
	
	cout<<"Please enter your choice of vehicle : ";
	  cin>>vech_ty;
	  date2=d_ate.date;                      //copying date to another variable.
if(vech_ty-1<7){
	cout<<"\n****JOURNEY INFORMATION****"<<endl<<endl;
	cout<<"For Single Journey:   press  'S' "<<endl;
	cout<<"For Resturn Journey:  press  'R' "<<endl;  
	cout<<"Please Enter your choice: ";
	  cin>>way;
	  
	cout<<"\nAvability of Monthly pass(Y/N): ";
	  cin>>monthly_pass;
	cout<<"Avability of Fast-tag(Y/N): ";
	  cin>>fast_tag;
	  /**extracting month and year from date**/
	  mon="";
	  yer = "";
	  for(int i = 3;i<=4;i++){
	  	mon = mon+d_ate.date[i];
	  }
	  for(int i = 6;i<=7;i++){
	  	yer = yer + d_ate.date[i];
	  }
}
	
}

float TollPlaza::Amount_Cal(){
	int n = vech_ty-1;
	if(monthly_pass=='Y' && fast_tag=='Y'){
	 cout<<"Considering fast tag only.\n\n";
		if(fast_tag=='Y' && n<7){
		if(way=='S'){
			f_bal = f_tag_bal[n] - toll_S_price[n];
			cout<<"Amount paid successfully from your account."<<endl;
			no_of_vehicle++;
		}
		else if(way=='R'){
			f_bal = f_tag_bal[n] - toll_R_price[n];
			cout<<"Amount paid successfully from your account."<<endl;
			no_of_vehicle++;
		}
	}
		
	}
	if(monthly_pass=='Y' && n<7){
	  cout<<"\n***Please Enter pass details***"<<endl;
	  cout<<"Enter Monthly Pass Number: ";
	  cin>>pass_no;
		if(way=='S'){
			 balance = monthly_bal[n]-toll_S_price[n];
			 cout<<"Amount paid successfully from your account."<<endl;
			 no_of_vehicle++;
		}
		else if(way=='R'){
			balance = monthly_bal[n]- toll_R_price[n];
			cout<<"Amount paid successfully from your account."<<endl;
			no_of_vehicle++;
		}	
	}
	else if(n==7){
		cout<<"Vehicle is of Exempt type."<<endl;
	}
	if(fast_tag=='Y' && n<7){
		if(way=='S'){
			f_bal = f_tag_bal[n] - toll_S_price[n];
			cout<<"Amount paid successfully from your account."<<endl;
			no_of_vehicle++;
		}
		else if(way=='R'){
			f_bal = f_tag_bal[n] - toll_R_price[n];
			cout<<"Amount paid successfully account."<<endl;
			no_of_vehicle++;
		}
	}
	else if(n == 7){
		cout<<"Vehicle is of Exempt type."<<endl;
	}
	 if(monthly_pass=='N' && fast_tag =='N'){
	 	if(way=='S'){
	 		cout<<"Amount to be paid: "<<toll_S_price[n]<<endl;
	 		cout<<"Amount received: ";
	 		cin>>amt;
	 		if(amt>toll_S_price[n]){
	 			cout<<"Amount returned: "<<abs(toll_S_price[n]-amt);
	 			
	 		}
	 		else{
	 			cout<<"Amount required: "<<abs(toll_S_price[n]-amt);
	 		}
	 		no_of_vehicle++;
	 		
	 	}
	 	else if(way=='R'){
	 		cout<<"price to be paid: "<<toll_R_price[n]<<endl;
	 		cout<<"Amount received: ";
	 		cin>>amt;
	 		if(amt>=toll_S_price[n]){
	 			cout<<"Amount returned: "<<abs(toll_R_price[n]-amt);
	 		}
	 		else{
	 			cout<<"Amount required: "<<abs(toll_R_price[n]-amt);
	 		}
	 		no_of_vehicle++;
	 	}
	 }
}


void TollPlaza::creating_file(){

		  /*************creating files operator wise**********/
		ofstream opw;
		opw.open("operator_wise", ios::ate | ios::app);
          opw<<"Date: "<<d_ate.date<<"\n";
		  opw<<"Operator_code: "<<opert_code<<"\n";
		  opw<<"Operator_name: "<<oper_t<<"\n";
		  opw<<"Number of vehicles: "<<no_of_vehicle<<"\n";
		  opw.close();
		  
		  
		ofstream vech_no;
		vech_no.open("Vehicle_No_store", ios::ate | ios::app);
		vech_no<<vehical_no<<"\n";
		vech_no.close();
		
		
		ofstream Lne;
		Lne.open("Lane_wise", ios::ate | ios::app);
		  Lne<<"Date: "<<d_ate.date<<"\n";
		  Lne<<"Lane: "<<lane<<"\n";
		  Lne<<"Number of vehicles: "<<no_of_vehicle<<"\n";
		  Lne.close();
		  
		ofstream Consol;
		Consol.open("Consolidate_wise",ios::ate|ios::app);
		  Consol<<"Date: "<<d_ate.date<<"\n";
		  Consol<<"Number of vehicles: "<<no_of_vehicle<<"\n";
		  Consol.close();
		  
		ofstream Vech;
		Vech.open("Vehicle_type",ios::app | ios::ate);
		  Vech<<d_ate.date<<"\n";
		  if(vech_ty==1)
		     Vech<<"Car/Jeep/Van"<<"\n";
          if(vech_ty==2)
		     Vech<<"Light Comercial Vehicle"<<"\n";
		  if(vech_ty==3)
		     Vech<<"Bus/Truck"<<"\n";
		  if(vech_ty==4)
		     Vech<<"Upto 3 Axle Vehicle"<<"\n";
		  if(vech_ty==5)
		     Vech<<"4 to 6 Axle"<<"\n";
		  if(vech_ty==6)
		     Vech<<"HCM/EMC"<<"\n";
		  if(vech_ty==7)
		     Vech<<"7 or more Axle"<<"\n";
		  if(vech_ty==8)
		     Vech<<"Exempt type-Ambulance/Police/Poltician"<<"\n\n";
		  Vech.close();
		  
		/***Creating file Month wise***/
		ofstream opw2;
		opw2.open("Moperator_wise", ios::ate | ios::app);
          opw2<<"Month: "<<mon<<"\n";
          opw2<<"Year: "<<yer<<"\n";
		  opw2<<"Operator_code: "<<opert_code<<"\n";
		  opw2<<"Operator name: "<<oper_t<<"\n";
		  opw2<<"Number of vehicles: "<<no_of_vehicle<<"\n";
		  opw2.close();
		  
		ofstream Lne2;
		Lne2.open("MLane_wise", ios::ate | ios::app);
		  Lne2<<"Month: "<<mon<<"\n";
          Lne2<<"Year: "<<yer<<"\n";
		  Lne2<<"Lane: "<<lane<<"\n";
		  Lne2<<"Number of vehicles: "<<no_of_vehicle<<"\n";
		  Lne2.close();
		  
		ofstream Consol2;
		Consol2.open("MConsolidate_wise",ios::ate|ios::app);
		  Consol2<<"Month: "<<mon<<"\n";
          Consol2<<"Year: "<<yer<<"\n";
		  Consol2<<"No. of vehicle: "<<no_of_vehicle<<"\n";
		  Consol2.close();
	}
	
	
int x=0,y=0;
void TollPlaza::search(int a){

	
	if(a==1){
		cout<<"List of Vehicles that can pass:\n\n";
	    cout<<"Car/Jeep/Van\n"
        <<"Light Comercial Vehicle\n"
	    <<"Bus/Truck\n"
	    <<"Upto 3 Axle Vehicle\n"
	    <<"4 to 6 Axle\n"
	    <<"HCM/EMC\n"
		<<"7 or more Axle\n"
	    <<"Exempt type-Ambulance/Police/Poltician\n\n";
	    
	    cout<<"Please select from above list to perform searching by vehicle type.\n\n";
	    
		int offset;
		string line;
		by_vech_ty = "";
	  	cout<<"Please enter vehicle type to be searched: ";
	  	cin>>by_vech_ty;
	  	
	  	ifstream  srch;
	  	srch.open("Vehicle_type");
	  	if(srch.is_open()){
	  		while(!srch.eof()){
	  			getline(srch,line);
	  			if((offset = line.find(by_vech_ty,0))!= string::npos){
	  				x++;
	  			}
	  		}
	  	}
	  	srch.close();
	  	cout<<"Number of times such vechicle passed: "<<x<<endl;
	  }
	if(a==2){
		int offset2;
		string line2;
		by_vech_no = "";
	  	cout<<"Please enter vehicle number to be searched: ";
	  	cin>>by_vech_no;
	  	
	  	ifstream  srch2;
	  	srch2.open("Vehicle_No_store");
	  	if(srch2.is_open()){
	  		while(!srch2.eof()){
	  			getline(srch2,line2);
	  			if((offset2 = line2.find(by_vech_no,0))!= string::npos){
	  				y++;
	  			}
	  		}
	  	}
	  	srch2.close();
	  	cout<<"Number of times that vechicle passed: "<<y<<endl;
	}
     
}
	


void TollPlaza::display(){
	int n1, choice;
	char ch1;
	cout<<endl<<"\nPlease confirm to save your file."<<endl;
	cout<<"Press  1  to save data."<<endl;
	cout<<"Press  2  to cancle."<<endl;
	cout<<"Please enter your choice: ";
	cin>>n1;
	cout<<"\nData saved SUCCESSFULLY!!\n\n";
	if(n1==1){
		A:{
		cout<<"\n**********REPORT DISPLAY**********"<<endl;
		cout<<"To display Daywise:  Press 'D' "<<"\n"
		    <<"To display Monthwise:  Press  'M' "<<"\n";
		cout<<"Please enter your choice: ";
		  cin>>ch1;
		  switch(ch1){
		  	case 'D': cout<<"\nSome further choices:"<<endl;
		  	          cout<<"Operator_wise:  Press 1"<<"\n"
		  	              <<"Lane_wise:      Press 2"<<"\n"
		  	              <<"Consolidated:   Press 3"<<"\n"
		  	              <<"Vehicle type:   Press 4"<<"\n";
		  	          cout<<"Please enter your choice: ";
		  	           cin>>choice;
		  	           break;
		  	           
		  	case 'M': cout<<"\nSome further choices:"<<endl;
		  	          cout<<"Operator_wise:  Press 1"<<"\n"
		  	              <<"Lane_wise:      Press 2"<<"\n"
		  	              <<"Consolidated:   Press 3"<<"\n"
		  	              <<"Vehicle type:   Press 4"<<"\n";
		  	          cout<<"Please enter your choice: ";
		  	           cin>>choice;
		  	           break;
						 
			
			default : cout<<"Please enter proper choice.";
			           goto A;
		    }
		  }
	/**code to display as per users choice**/
		  if(ch1=='D'){
		  	 if(choice==1){
		  	 	ifstream oper;
		  	 	oper.open("operator_wise");
		  	 	
		        char chr;
		        while(oper){
		        	chr = oper.get();
		        	if(chr==EOF)
		        	break;
		        	else{
		        		cout<<chr;
		        	}
		        	
		        }//end of while 
				cout<<"\n";  
		  	 }//end of choice 1
		  	 
		  	 if(choice==2){
		  	 	ifstream Lan;
		  	 	Lan.open("Lane_wise");
		  	 	
		        char chr;
		        while(Lan){
		        	chr = Lan.get();
		        	if(chr==EOF)
		        	break;
		        	else{
		        		cout<<chr;
		        	}
		        	
		        }
		        cout<<"\n";
		  	
		  }//end of choice 2
		  
		  	  	 if(choice==3){
		  	 	ifstream con;
		  	 	con.open("Consolidate_wise");
		  	 	
		        char chr;
		        while(con){
		        	chr = con.get();
		        	if(chr==EOF)
		        	break;
		        	else{
		        		cout<<chr;
		        	}
		        	
		        }
		        cout<<"\n";
		  	
		  }//end of choice 3
		  
			 if(choice==4){
		  	 	ifstream VEH;
		  	 	VEH.open("Vehicle_type");
		  	 	
		        char chr;
		        while(VEH){
		        	chr = VEH.get();
		        	if(chr==EOF)
		        	break;
		        	else{
		        		cout<<chr;
		        	}
		        	
		        }
		        cout<<"\n";
		  	
		  }//end of choice 4	  
   }//end of D
   if(ch1=='M'){
		  	 if(choice==1){
		  	 	ifstream oper;
		  	 	oper.open("Moperator_wise");
		  	 	
		        char chr;
		        while(oper){
		        	chr = oper.get();
		        	if(chr==EOF)
		        	break;
		        	else{
		        		cout<<chr;
		        	}
		        	
		        }//end of while   
		        cout<<"\n";
		  	 }//end of choice 1
		  	 
		  	 if(choice==2){
		  	 	ifstream Lan;
		  	 	Lan.open("MLane_wise");
		  	 	
		        char chr;
		        while(Lan){
		        	chr = Lan.get();
		        	if(chr==EOF)
		        	break;
		        	else{
		        		cout<<chr;
		        	}
		        	
		        }
		        cout<<"\n";
		  	
		  }//end of choice 2
		  
		  	  	 if(choice==3){
		  	 	ifstream con;
		  	 	con.open("MConsolidate_wise");
		  	 	
		        char chr;
		        while(con){
		        	chr = con.get();
		        	if(chr==EOF)
		        	break;
		        	else{
		        		cout<<chr;
		        	}
		        	
		        }
		        cout<<"\n";
		  	
		  }//end of choice 3
		  
      }//end of M
      
   }//end for save function
   if(n1==2){
   	cout<<"Cancle is opted by the user."<<"\n";
   	return;
   }
}
main(){
	Rep:
		cout<<"\n\n";
	int ch;
	TollPlaza t;
	
	int num;
	cout<<"+*+*+*+*WELCOME TO TOLL_PLAZA SYSTEM*+*+*+*+*+\n\n";
	cout<<"\n\nPlease provide your choice to perform required operation.\n\n";
	cout<<"To fill the Operation details:  Press 1"<<"\n"
	    <<"To perform searching:  Press 2\n\n";
	 cin>>num;
	if(num==1){ 
	t.input();
	t.Amount_Cal();
	t.creating_file();
	t.display();
	cout<<"\n\n@*@*@*@*@*@*@*@*@*@*@*@*@*@* !!!!THANK YOU FOR USING!!!! *@*@*@*@*@*@*@*@*@*@*@*@*@*@*@\n\n";
	cout<<"\n\nPlease enter further choice to continue: ";
	cout<<"\n\nTo continue and enter further data press 1"<<"\n"
	    <<"To exit press 2"<<"\n";
	cin>>ch;
	if(ch==1){
		t.distruct();
		goto Rep;
	}
	if(ch==2){
		exit(0);
	}
}
if(num==2){
	char ch_ice;
	int num2;
	  cout<<"\n\n*-*-*-*-*-*-*-*-*WELCOME TO SEARCHING INTERFACE*-*-*-*-*-*-*-*-\n\n";
	  cout<<"Please specify the type of searching to be performed..\n\n";
	  cout<<"To search by vehicle type:    Press  1\n";
	  cout<<"To search by vehicle number:  Press  2\n";
	  cin>>num2;
	  t.search(num2);
	  cout<<"Please press A to move back to previous options.\n"
	     <<"Please press B to exit.\n\n";  
	  cin>>ch_ice;
	  if(ch_ice=='A'){
	  		t.distruct();
		    goto Rep;
	  }
	  if(ch_ice=='B'){
	  	 exit(0);
	  }
	  
  }
}



